import cv2
import numpy as np
import tensorflow as tf
import os
import time
from picamera2 import Picamera2  # For Raspberry Pi camera module

# Define the custom Cast layer
class Cast(tf.keras.layers.Layer):
    def call(self, inputs):
        return tf.cast(inputs, tf.float32)

# Load the model with custom_objects
model_path = r"/home/pi/mobilenetv2_weed_classifier.h5"  # Update this path to your model location
print(f"Checking if model file exists: {os.path.exists(model_path)}")

try:
    print("Loading model...")
    model = tf.keras.models.load_model(
        model_path,
        custom_objects={'Cast': Cast}
    )
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")
    exit(1)

# Define class names
class_names = [
    'Brassica juncea',
    'Calotropis gigantea',
    'Cannabis sativa',
    'Carrot',
    'Cirisium hookerium',
    'Fennel',
    'Garlic',
    'Santa maria feverfew',
    'Turmeric',
    'Xanthium strumarium'
]

# Image preprocessing
def preprocess_image(img):
    img = cv2.resize(img, (224, 224))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = img.astype(np.float32) / 255.0
    img = np.expand_dims(img, axis=0)
    return img

# Function to predict from image
def predict_image(img):
    processed_img = preprocess_image(img)
    
    try:
        predictions = model.predict(processed_img, verbose=0)
        
        # Check for NaN values
        if np.isnan(predictions).any():
            print("WARNING: NaN values detected in predictions!")
            return "Unknown", 0, []
        
        class_id = np.argmax(predictions[0])
        confidence = predictions[0][class_id]
        predicted_class = class_names[class_id]
        
        # Get top 3 predictions
        top_indices = np.argsort(predictions[0])[-3:][::-1]
        top_3 = [(class_names[idx], predictions[0][idx]) for idx in top_indices]
        
        return predicted_class, confidence, top_3
        
    except Exception as e:
        print(f"Error during prediction: {e}")
        return "Error", 0, []

# Initialize camera
def initialize_camera():
    try:
        # Initialize the Picamera2
        picam2 = Picamera2()
        
        # Configure the camera
        preview_config = picam2.create_preview_configuration(
            main={"size": (1280, 720), "format": "RGB888"}
        )
        picam2.configure(preview_config)
        
        # Start the camera
        picam2.start()
        time.sleep(2)  # Give time for camera to warm up
        
        print("Camera initialized successfully")
        return picam2
    except Exception as e:
        print(f"Error initializing camera: {e}")
        return None

# Capture a single image
def capture_image(camera):
    print("Capturing image in 3 seconds...")
    for i in range(3, 0, -1):
        print(f"{i}...")
        time.sleep(1)
    
    # Capture image
    img = camera.capture_array()
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)  # Convert to BGR for OpenCV
    return img

# Process a single captured image
def process_captured_image(camera):
    img = capture_image(camera)
    
    # Make prediction
    predicted_class, confidence, top_3 = predict_image(img)
    
    # Display results
    print("\n--- PREDICTION RESULT ---")
    print(f"Predicted class: {predicted_class}")
    print(f"Confidence: {confidence:.4f}")
    
    print("\nTop 3 predictions:")
    for i, (class_name, conf) in enumerate(top_3):
        print(f"{i+1}. {class_name}: {conf:.4f}")
    
    # Display image with prediction
    output_img = img.copy()
    label = f"{predicted_class}: {confidence:.2f}"
    cv2.putText(output_img, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    
    cv2.imshow("Prediction Result", output_img)
    print("\nDisplaying image with prediction. Press any key to close.")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Process video stream
def process_video_stream(camera):
    print("Video mode activated. Press 'q' to quit.")
    
    try:
        while True:
            # Capture frame
            img = camera.capture_array()
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)  # Convert to BGR for OpenCV
            
            # Make prediction (time this operation)
            start_time = time.time()
            predicted_class, confidence, _ = predict_image(img)
            process_time = time.time() - start_time
            
            # Display prediction on frame
            output_img = img.copy()
            fps_text = f"FPS: {1/process_time:.1f}"
            prediction_text = f"{predicted_class}: {confidence:.2f}"
            
            cv2.putText(output_img, prediction_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            cv2.putText(output_img, fps_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            
            # Display the frame
            cv2.imshow("Weed Detection", output_img)
            
            # Exit on 'q' press
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    except KeyboardInterrupt:
        print("Interrupted by user")
    finally:
        cv2.destroyAllWindows()

# Main menu
def main_menu():
    # Initialize camera
    camera = initialize_camera()
    if camera is None:
        print("Failed to initialize camera. Exiting...")
        return
    
    while True:
        print("\n=== WEED DETECTION SYSTEM ===")
        print("1. Capture and process image")
        print("2. Video mode")
        print("3. Exit")
        
        choice = input("Enter your choice (1-3): ")
        
        if choice == '1':
            process_captured_image(camera)
        elif choice == '2':
            process_video_stream(camera)
        elif choice == '3':
            print("Exiting program...")
            break
        else:
            print("Invalid choice. Please try again.")
    
    # Clean up
    camera.stop()

if __name__ == "__main__":
    main_menu()